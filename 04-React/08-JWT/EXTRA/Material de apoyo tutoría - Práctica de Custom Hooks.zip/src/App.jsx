function App() {
  return (
    <>
      <h1>Practicando con Custom Hooks</h1>

      <button>+1</button>
      <button>-1</button>
      <button>Reiniciar</button>
    </>
  );
}

export default App;
