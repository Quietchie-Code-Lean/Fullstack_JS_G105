import { useState } from 'react';
import data from './data.json';
import NoDisponible from './NoDisponible';

function App() {
  // estado para los productos de la lista
  const [productos, setProductos] = useState(data);

  return (
    <div className="container">
      <div className="col-md-8">
        <h4>Listas react</h4>
        <ul>
          {productos.map((producto) => (
            <li className="d-flex mb-3" key={producto.id}>
              {producto.id} - {producto.nombre}, precio:
              <span className="text-primary">{producto.precio}</span>
              {!producto.disponible ? <NoDisponible /> : null}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
